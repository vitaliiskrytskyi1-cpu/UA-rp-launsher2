@echo off
cd /d "%~dp0"
omp-server.exe
pause
