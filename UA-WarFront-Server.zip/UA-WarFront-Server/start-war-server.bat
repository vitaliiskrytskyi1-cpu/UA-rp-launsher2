@echo off
cd /d "%~dp0"
echo UA War Front server, UDP port 7000
"Godot_v4.3-stable_win64_console.exe" --headless --path game -- --server --port=7000
pause
